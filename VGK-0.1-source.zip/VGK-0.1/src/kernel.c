#include <stdint.h>
#include <stddef.h>

#define VGA_TEXT ((volatile uint16_t *)0xB8000)
#define VGA_COLS 80u
#define VGA_ROWS 25u

static size_t cursor = 0;

static inline void outb(uint16_t port, uint8_t value) {
    __asm__ volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static void serial_init(void) {
    outb(0x3F9, 0x00);
    outb(0x3FB, 0x80);
    outb(0x3F8, 0x03);
    outb(0x3F9, 0x00);
    outb(0x3FB, 0x03);
    outb(0x3FA, 0xC7);
    outb(0x3FC, 0x0B);
}

static void serial_write(const char *s) {
    while (*s) {
        /* Bound the wait: a machine without a responding COM1 must still boot. */
        unsigned int timeout = 100000u;
        while ((inb(0x3FD) & 0x20u) == 0 && --timeout != 0u) { }
        if (timeout == 0u) return;
        outb(0x3F8, (uint8_t)*s++);
    }
}

static void screen_clear(void) {
    for (size_t i = 0; i < VGA_COLS * VGA_ROWS; ++i)
        VGA_TEXT[i] = (uint16_t)0x0720;
    cursor = 0;
}

static void screen_putc(char c, uint8_t color) {
    if (c == '\r') return;
    if (c == '\n') {
        cursor = ((cursor / VGA_COLS) + 1u) * VGA_COLS;
    } else {
        if (cursor < VGA_COLS * VGA_ROWS)
            VGA_TEXT[cursor] = (uint16_t)((uint16_t)color << 8) | (uint8_t)c;
        ++cursor;
    }
    if (cursor >= VGA_COLS * VGA_ROWS) cursor = 0;
}

static void screen_write(const char *s, uint8_t color) {
    while (*s) screen_putc(*s++, color);
}

/* Multiboot2 entry: EAX=boot magic, EBX=physical address of boot info. */
void vgk_entry(uint32_t magic, uint32_t mbi_address) {
    (void)mbi_address;
    serial_init();
    screen_clear();
    if (magic == 0x36d76289u) {
        screen_write("VGK 0.1 - independent kernel booted\n", 0x0A);
        screen_write("Multiboot2 handoff received.\n", 0x07);
        serial_write("VGK 0.1: BOOT OK\r\nMultiboot2 handoff received.\r\n");
    } else {
        screen_write("VGK: invalid bootloader handoff\n", 0x0C);
        serial_write("VGK: INVALID MULTIBOOT2 HANDOFF\r\n");
    }
    for (;;) __asm__ volatile ("cli; hlt");
}
