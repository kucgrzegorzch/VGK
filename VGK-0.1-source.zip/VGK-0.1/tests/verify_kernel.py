#!/usr/bin/env python3
"""Static sanity checks for the VGK Multiboot2 x86-64 kernel."""
import struct
import subprocess
import sys
from pathlib import Path

p = Path(sys.argv[1])
data = p.read_bytes()
assert data[:4] == b"\x7fELF", "not an ELF file"
assert data[4] == 2, "ELF is not 64-bit"
assert data[5] == 1, "ELF is not little-endian"
e_type, machine = struct.unpack_from("<HH", data, 16)
assert e_type == 2, "kernel is not a static executable ELF"
assert machine == 62, "ELF machine is not x86-64"
entry = struct.unpack_from("<Q", data, 24)[0]
assert entry != 0, "ELF entry point is zero"

magic = struct.pack("<I", 0xE85250D6)
off = data.find(magic, 0, 32768)
assert off >= 0, "Multiboot2 header not found in first 32 KiB"
mb_magic, arch, length, checksum = struct.unpack_from("<IIII", data, off)
assert mb_magic == 0xE85250D6 and arch == 0, "invalid Multiboot2 header fields"
assert length >= 24 and off + length <= len(data), "invalid Multiboot2 header length"
assert (mb_magic + arch + length + checksum) & 0xFFFFFFFF == 0, "Multiboot2 checksum mismatch"
assert data[off + 16:off + 24] == b"\x00\x00\x00\x00\x08\x00\x00\x00", "missing Multiboot2 end tag"

undefined = subprocess.check_output(["nm", "-u", str(p)], text=True).strip()
assert not undefined, f"undefined symbols found: {undefined}"
print(f"PASS: {p} is ELF64 x86-64, entry=0x{entry:x}")
print(f"PASS: Multiboot2 header at file offset 0x{off:x}; checksum valid")
print("PASS: no undefined external symbols")
