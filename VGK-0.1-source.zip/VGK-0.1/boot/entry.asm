/* GNU assembler syntax. Multiboot2 enters in 32-bit protected mode;
   establish identity-mapped long mode before calling the x86-64 kernel. */
.section .multiboot2,"a"
.align 8
header_start:
    .long 0xe85250d6
    .long 0
    .long header_end - header_start
    .long -(0xe85250d6 + (header_end - header_start))
    .short 0
    .short 0
    .long 8
header_end:

.section .bss
.align 16
stack_bottom: .skip 16384
stack_top:
.align 4
boot_magic: .long 0
boot_info: .long 0
.align 4096
pml4: .skip 4096
.align 4096
pdpt: .skip 4096
.align 4096
pd: .skip 4096

.section .rodata
.align 8
gdt64:
    .quad 0
    .quad 0x00AF9A000000FFFF
    .quad 0x00CF92000000FFFF
gdt64_end:
gdt64_ptr:
    .word gdt64_end - gdt64 - 1
    .long gdt64

.section .text
.global _start
.type _start, @function
.code32
_start:
    cli
    mov %eax, boot_magic
    mov %ebx, boot_info

    /* Refuse to enter long mode unless CPUID reports x86-64 support. */
    mov $0x80000000, %eax
    cpuid
    cmp $0x80000001, %eax
    jb unsupported_cpu
    mov $0x80000001, %eax
    cpuid
    test $(1 << 29), %edx
    jz unsupported_cpu

    /* Build a 1 GiB identity map using 2 MiB pages. */
    mov $pml4, %eax
    or $0x03, %eax
    mov %eax, pml4
    mov $pdpt, %eax
    or $0x03, %eax
    mov %eax, pdpt

    mov $pd, %edi
    mov $0, %ecx
1:
    mov %ecx, %eax
    shl $21, %eax
    or $0x83, %eax
    mov %eax, (%edi,%ecx,8)
    movl $0, 4(%edi,%ecx,8)
    inc %ecx
    cmp $512, %ecx
    jne 1b

    lgdt gdt64_ptr
    mov %cr4, %eax
    or $0x20, %eax
    mov %eax, %cr4
    mov $pml4, %eax
    mov %eax, %cr3

    mov $0xC0000080, %ecx
    rdmsr
    or $0x100, %eax
    wrmsr

    mov %cr0, %eax
    or $0x80000001, %eax
    mov %eax, %cr0
    ljmp $0x08, $long_mode_entry

unsupported_cpu:
    cli
3:
    hlt
    jmp 3b

.code64
long_mode_entry:
    mov $0x10, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %ss
    mov $stack_top, %rsp
    and $-16, %rsp
    mov boot_magic(%rip), %edi
    mov boot_info(%rip), %esi
    call vgk_entry
2:
    cli
    hlt
    jmp 2b
.size _start, . - _start

.section .note.GNU-stack,"",@progbits
